# AI×商標：イメージサーチコンペティション（類似商標画像の検出） チュートリアル

[AI×商標：イメージサーチコンペティション（類似商標画像の検出）](https://www.nishika.com/competitions/22/summary)コンペティションのチュートリアルコードです。<br>
以下環境・手順での動作確認を行なっています。

## ハードウェア
- AWS EC2
- Deep Learning AMI on Ubuntu 18.04 LTS
- インスタンスタイプ: g4dn.2xlarge (1GPU, 8vCPU, メモリ32GB)
- ディスクサイズ: 500GB

## ソフトウェア
- Miniconda3 Linux 64-bit (Latest - Conda 4.10.3 Python 3.9.5 released July 21, 2021)
- Python 3.9.7

## ディレクトリ構造
```
root/
　├ data/
　│　├ input/
　│　│　├ apply_images/
　│　│　├ cite_images/
　│　│　├ train.csv
　│　│　├ cite.csv
　│　│　├ test.csv
　│　│　└ sample_submission.csv
　│　└ output/
　├ models/
　├ notebooks/
　│　└ tutorial_check_train_data.ipynb
　├ scripts/
　│　├ 00_tutorial_setup.sh         - 環境構築
　│　├ 01_tutorial_preprocess.py    - 前処理
　│　├ 02_tutorial_train.py         - 学習
　│　├ 03_tutorial_infer.py         - 推論（特徴ベクトル取得）
　│　├ 04_tutorial_ann.py           - 近似最近傍探索
　│　└ 05_tutorial_submit.py        - 投稿ファイル作成
　└ requirements.txt
```

## 実行手順
コンペティションページからデータをダウンロードし、`data/input`に置いた上で、`scripts`に移動し以下を順次実行

```bash
00_tutorial_setup.sh
01_tutorial_preprocess.py
02_tutorial_train.py
03_tutorial_infer.py
04_tutorial_ann.py
05_tutorial_submit.py
```

## 考え方
- `tutorial_check_train_data.ipynb`にあるように、いくつかの出願画像と引用画像のペアを見てみると、余白に差がある。元画像をそのまま使うと余白に引っ張られた検索結果となってしまうことから、`01_tutorial_preprocess.py`で余白を削除
- 類似検索を行うにあたって画像を特徴ベクトルに変換したいが、その手法として深層距離学習を用いる。距離学習は、クラス間のサンプル間の距離を大きくし、クラス内のサンプル間の距離を小さくするように学習させる手法。本チュートリアルではモデルとしてEfficientNet、損失関数としてArcFaceを採用（AdaCosなども利用可能）。深層距離学習やArcFaceに関する解説は[こちら](https://tech-blog.optim.co.jp/entry/2021/10/01/100000)など。
- `02_tutorial_train.py`でtrain.csvの画像ペアを用いてモデルを学習し、`03_tutorial_infer.py`でtest.csv, cite.csv各々の画像について特徴ベクトルを獲得。
- 本タスクでは検索対象が80万件超存在することから、特徴ベクトル同士の類似度を全て計算して・・・とやっていると非常に時間がかかってしまう。そこで、類似ベクトルを高速に探索できる近似最近傍探索を行う。
- 近似最近傍探索のライブラリは[Annoy](https://github.com/spotify/annoy), [faiss](https://github.com/facebookresearch/faiss), [nmslib](https://github.com/nmslib/nmslib)などがあるが、`04_tutorial_ann.py`ではnmslibを採用し、検索インデックスを作成。
- `05_tutorial_submit.py`で投稿データ用に整形。

## 主な改善点
- 前処理として、余白の削除しか行なっておらず、類似検索結果を見ると文字の存在に引っ張られた結果となっている。実際には、文字以外の箇所に基づいて類似の判定がなされている場合が多いため、文字を取り除く処理が効果的と思われる

## 利用時の注意
[評価方法](https://www.nishika.com/competitions/22/summary#evaluation)に記載の通り、入賞時提出物としては`get_result`関数を定義する必要があるが、本チュートリアルコードは分かりやすさのため、そのように構成していない点に注意