#!/bin/bash

# ライブラリインストール
pip install -r ../requirements.txt
pip install --no-binary :all: nmslib

# Pytorchの画像系モデルが利用可能なライブラリtimmを導入
git clone https://github.com/rwightman/pytorch-image-models
cd pytorch-image-models && git checkout f83b0b0 # 特定のコミットにチェックアウトし、本リポジトリの将来の変更の影響を受けないようにする