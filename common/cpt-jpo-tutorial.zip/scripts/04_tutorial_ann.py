"""nmslibを使い、CPU上で近似最近傍探索"""

# Import Libraries

import os
import pickle
import time
from tqdm import trange

import nmslib
import numpy as np
import pandas as pd


# load data

is_debug = False # debug時はTrueに

if is_debug:
    nall = 10000
    ntarget = 10
    embeds = np.random.rand(nall, 1000)
    target_idxs = [i for i in range(ntarget)]
    true_idxs = [i for i in range(ntarget, nall)]
    query_arrays = embeds[target_idxs]
    search_arrays = embeds[true_idxs]
else:
    query_arrays = np.load(f'../data/output/test_image_embeddings.npy')
    search_arrays = np.load(f'../data/output/cite_image_embeddings.npy')

test_df = pd.read_csv('../data/input/test.csv')
test_idx2id = dict(zip(test_df.index, test_df['gid']))
cite_df = pd.read_csv('../data/input/cite.csv')
cite_idx2id = dict(zip(cite_df.index, cite_df['gid']))
del test_df, cite_df

# create/load index

index = nmslib.init(method='hnsw', space='cosinesimil')

if os.path.exists(f'../models/index.ann'):

    print(f'load index starts')
    start = time.time()

    index.loadIndex(f'../models/index.ann')

    end = time.time()
    print(f'load index takes {end-start} sec')

else:

    print(f'create index starts')
    start = time.time()

    index.addDataPointBatch(search_arrays)
    index.createIndex({'post': 2}, print_progress=True)

    end = time.time()
    print(f'create index takes {end-start} sec')

    index.saveIndex(f'../models/index.ann')


# get neighbors

start = time.time()

sim_ids_dict = {}
sim_dists_dict = {}

for i in trange(query_arrays.shape[0]):

    idxs, dists = index.knnQuery(query_arrays[i], k=1000)
    ids = [cite_idx2id[idx] for idx in idxs]
    base_id = test_idx2id[i]
    sim_ids_dict[base_id] = ids
    sim_dists_dict[base_id] = dists


end = time.time()
print(f'get neighbors takes {end-start} sec')

del search_arrays, query_arrays, index


# save results

print(f'save idxs starts')
with open(f'../data/output/similar_ids.pickle', 'wb') as f:
    pickle.dump(sim_ids_dict, f)
print(f'save idxs ends')

print(f'save dists starts')
with open(f'../data/output/similar_dists.pickle', 'wb') as f:
    pickle.dump(sim_dists_dict, f)
print(f'save dists ends')