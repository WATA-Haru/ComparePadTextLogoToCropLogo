"""
前処理として余白の削除、train.csvを学習用に整形するなどを実施
"""

import os
from tqdm import tqdm

import cv2
import numpy as np
import pandas as pd
from joblib import Parallel, delayed


BASE_PATH = '../data/input/'


def crop_image(path):

    img = cv2.imread(path)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    img2 = cv2.threshold(gray, 127, 255, cv2.THRESH_BINARY)[1]
    contours = cv2.findContours(img2, cv2.RETR_TREE, cv2.CHAIN_APPROX_SIMPLE)[0]
    x1 = [] #x座標の最小値
    y1 = [] #y座標の最小値
    x2 = [] #x座標の最大値
    y2 = [] #y座標の最大値
    for i in range(1, len(contours)):
        ret = cv2.boundingRect(contours[i])
        x1.append(ret[0])
        y1.append(ret[1])
        x2.append(ret[0] + ret[2])
        y2.append(ret[1] + ret[3])

    if x1:
        x1_min = min(x1)
        y1_min = min(y1)
        x2_max = max(x2)
        y2_max = max(y2)
        crop_img = img[y1_min:y2_max, x1_min:x2_max]
    else:
        crop_img = img

    return crop_img


def make_crop(input):
    input_path, output_path, output_dir = input
    crop_img = crop_image(input_path)
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    cv2.imwrite(output_path, crop_img)
    return


# train.csv記載の画像をcropし保存。train.csvのパスも書き換え

df = pd.read_csv(f'../data/input/train.csv')

## 出願画像の処理
paths = df['path'].values
base_input_path = BASE_PATH+'apply_images/'
input_paths = [base_input_path+path for path in paths]
output_paths = []
inputs = []
for input_path in tqdm(input_paths):
    output_path = BASE_PATH + f'crop_train_apply_images/' + '/'.join(input_path.split('/')[-2:])
    output_dir = BASE_PATH + f'crop_train_apply_images/' + input_path.split('/')[-2]
    output_paths.append(output_path)
    inputs.append([input_path, output_path, output_dir])
_ = Parallel(n_jobs=-1)(delayed(make_crop)(input) for input in tqdm(inputs)) # 並列処理
df['path'] = '../data/input/crop_train_apply_images/' + df['path']

## 引用画像の処理
paths = df['cite_path'].values
base_input_path = BASE_PATH+'cite_images/'
input_paths = [base_input_path+path for path in paths]
output_paths = []
inputs = []
for input_path in tqdm(input_paths):
    output_path = BASE_PATH + f'crop_train_cite_images/' + '/'.join(input_path.split('/')[-2:])
    output_dir = BASE_PATH + f'crop_train_cite_images/' + input_path.split('/')[-2]
    output_paths.append(output_path)
    inputs.append([input_path, output_path, output_dir])
_ = Parallel(n_jobs=-1)(delayed(make_crop)(input) for input in tqdm(inputs)) # 並列処理
df['cite_path'] = '../data/input/crop_train_cite_images/' + df['cite_path']


# test.csv記載の画像をcropし保存。全て同じディレクトリに保存するのでtest.csvのパスの書き換えはしない

test_df = pd.read_csv(f'../data/input/test.csv')

## 出願画像の処理
paths = test_df['path'].values
base_input_path = BASE_PATH+'apply_images/'
input_paths = [base_input_path+path for path in paths]
output_paths = []
inputs = []
for input_path in tqdm(input_paths):
    output_path = BASE_PATH + f'crop_test_images/' + '/'.join(input_path.split('/')[-2:])
    output_dir = BASE_PATH + f'crop_test_images/' + input_path.split('/')[-2]
    output_paths.append(output_path)
    inputs.append([input_path, output_path, output_dir])
_ = Parallel(n_jobs=-1)(delayed(make_crop)(input) for input in tqdm(inputs)) # 並列処理


# cite.csv記載の画像をcropし保存。全て同じディレクトリに保存するのでcite.csvのパスの書き換えはしない

cite_df = pd.read_csv(f'../data/input/cite.csv')

## 出願画像の処理
paths = cite_df['path'].values
base_input_path = BASE_PATH+'cite_images/'
input_paths = [base_input_path+path for path in paths]
output_paths = []
inputs = []
for input_path in tqdm(input_paths):
    output_path = BASE_PATH + f'crop_cite_images/' + '/'.join(input_path.split('/')[-2:])
    output_dir = BASE_PATH + f'crop_cite_images/' + input_path.split('/')[-2]
    output_paths.append(output_path)
    inputs.append([input_path, output_path, output_dir])
_ = Parallel(n_jobs=-1)(delayed(make_crop)(input) for input in tqdm(inputs)) # 並列処理


# train.csvを学習用に整形

train_ratio, val_ratio = 8, 2
val_idx = int(df.shape[0]*train_ratio/10)
df['split'] = 'train'
df.loc[val_idx:, 'split'] = 'val'

data = []
apply_gids = df['gid'].values
cite_gids = df['cite_gid'].values
apply_paths = df['path'].values
cite_paths = df['cite_path'].values
splits = df['split'].values
categories = df['category'].values
for apply_gid, cite_gid, apply_path, cite_path, split, category in zip(apply_gids, cite_gids, apply_paths, cite_paths, splits, categories):
    data.append([int(cite_gid), cite_path, int(cite_gid), cite_path, split, 'cite', category])
    data.append([int(apply_gid), apply_path, int(cite_gid), cite_path, split, 'apply', category])
new_df = pd.DataFrame(data, columns=['gid', 'path', 'cite_gid', 'cite_path', 'split', 'apply/cite', 'category'])
new_df = new_df.drop_duplicates(subset=['path', 'cite_path']) # 正解ペアが全く同一のレコードは削除

new_df.to_csv(f'../data/input/train_preprocessed.csv', index=False)